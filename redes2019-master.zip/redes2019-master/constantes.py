#!/usr/bin/env python
# encoding: utf-8
"""
Constants.py
"""

SOURCE_PORT = 20000
RECEIVER_PORT = 20001
SOURCE_IP = 'localhost'
RECEIVER_IP = 'localhost'