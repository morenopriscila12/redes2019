#!/usr/bin/env python
# encoding: utf-8
"""
constantes.py
"""
from pickle import *
from paquete import *
import signal
import sys
from functools import partial
from socket import *


NETWORK_IP      = 'localhost'
NETWORK_PORT    = 12000
EMISOR_IP       = 'localhost'
EMISOR_PORT     = 12001
RECEPTOR_IP     = 'localhost'
RECEPTOR_PORT   = 12002
